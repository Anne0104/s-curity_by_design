const axios = require('axios');

const SITE_KEY = '6LdJOjcrAAAAAITHe43jWCPPA6hGuWRAxWY7_qAs';
const SECRET_KEY = '6LdJOjcrAAAAAAC_-oHnsYOttX2iGuD1eTCEDcer';

async function verify(token) {
  const url = 'https://www.google.com/recaptcha/api/siteverify';
  const params = new URLSearchParams();
  params.append('secret', SECRET_KEY);
  params.append('response', token);

  const { data } = await axios.post(url, params, {
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' }
  });
  return data.success;
}

module.exports = { verify, SITE_KEY };